

<?php $__env->startSection('title', __('dashboard.title')); ?>
<?php $__env->startSection('page_title', __('dashboard.title')); ?>

<?php $__env->startSection('content'); ?>

<div class="welcome-card mb-4">
    <h2><?php echo e(__('dashboard.welcome', ['name' => auth()->user()->name])); ?></h2>
    <p class="text-muted mb-1"><?php echo e(now()->translatedFormat('l, d F Y')); ?></p>
    <p class="mb-0"><?php echo e(__('dashboard.description')); ?></p>
</div>


<div class="row g-4 mb-4">
    <?php $__currentLoopData = $stats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-6 col-xl-3">
            <div class="stat-card card h-100">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-start">
                        <div>
                            <p class="stat-label"><?php echo e($stat['label']); ?></p>
                            <h3 class="stat-value"><?php echo e(number_format($stat['value'])); ?></h3>
                            <?php if(! empty($stat['note'])): ?>
                                <small class="text-muted"><?php echo e($stat['note']); ?></small>
                            <?php endif; ?>
                        </div>
                        <div class="stat-icon bg-<?php echo e($stat['color']); ?>-subtle text-<?php echo e($stat['color']); ?>">
                            <i class="bi <?php echo e($stat['icon']); ?>"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>


<div class="row g-4">
    <div class="col-lg-8">
        <div class="chart-placeholder card h-100">
            <div class="card-body d-flex flex-column align-items-center justify-content-center">
                <i class="bi bi-graph-up display-4 text-muted mb-3"></i>
                <h5><?php echo e(__('dashboard.records_overview')); ?></h5>
                <p class="text-muted mb-0"><?php echo e(__('dashboard.chart_placeholder')); ?></p>
            </div>
        </div>
    </div>
    <div class="col-lg-4">
        <div class="chart-placeholder card h-100">
            <div class="card-body d-flex flex-column align-items-center justify-content-center">
                <i class="bi bi-pie-chart display-4 text-muted mb-3"></i>
                <h5><?php echo e(__('dashboard.records_by_category')); ?></h5>
                <p class="text-muted mb-0"><?php echo e(__('dashboard.chart_placeholder')); ?></p>
            </div>
        </div>
    </div>
 
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\pc\Music\Crises-dashboard\resources\views/admin/dashboard/index.blade.php ENDPATH**/ ?>