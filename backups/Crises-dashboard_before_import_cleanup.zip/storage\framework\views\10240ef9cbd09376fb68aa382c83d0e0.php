
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Import History</title>

    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet"
    >
</head>
<body class="bg-light">

<div class="container py-5">

    <h1 class="mb-4">Import History</h1>

    <form method="GET" action="<?php echo e(route('imports.history')); ?>" class="card card-body mb-4">

        <div class="row g-3">

            <div class="col-md-5">
                <label class="form-label">Search</label>

                <input
                    type="text"
                    name="search"
                    class="form-control"
                    value="<?php echo e(request('search')); ?>"
                    placeholder="Search filename or organizational unit"
                >
            </div>

            <div class="col-md-3">
                <label class="form-label">Status</label>

                <select name="status" class="form-select">
                    <option value="">All statuses</option>

                    <?php $__currentLoopData = ['pending', 'processing', 'completed', 'failed']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option
                            value="<?php echo e($status); ?>"
                            <?php if(request('status') === $status): echo 'selected'; endif; ?>
                        >
                            <?php echo e(ucfirst($status)); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="col-md-2 d-flex align-items-end">
                <button class="btn btn-primary w-100">
                    Filter
                </button>
            </div>

            <div class="col-md-2 d-flex align-items-end">
                <a href="<?php echo e(route('imports.history')); ?>" class="btn btn-outline-secondary w-100">
                    Reset
                </a>
            </div>

        </div>
    </form>

    <div class="card shadow-sm">

        <div class="table-responsive">

            <table class="table table-striped table-hover align-middle mb-0">

                <thead class="table-dark">
                    <tr>
                        <th>Batch ID</th>
                        <th>Filename</th>
                        <th>Target Table</th>
                        <th>Organizational Unit</th>
                        <th>Total Rows</th>
                        <th>Imported</th>
                        <th>Failed</th>
                        <th>Status</th>
                        <th>Created At</th>
                    </tr>
                </thead>

                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $batches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $batch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td>
    <a href="<?php echo e(route('imports.history.show', $batch)); ?>"
       class="text-decoration-none fw-bold">
        #<?php echo e($batch->id); ?>

    </a>
</td>

                            <td><?php echo e($batch->original_filename); ?></td>

                            <td><?php echo e($batch->target_table); ?></td>

                            <td><?php echo e($batch->organizational_unit ?? '-'); ?></td>

                            <td><?php echo e($batch->total_rows); ?></td>

                            <td><?php echo e($batch->imported_rows); ?></td>

                            <td><?php echo e($batch->failed_rows); ?></td>

                            <td>
                                <?php
                                    $badgeClass = match($batch->status) {
                                        'completed' => 'success',
                                        'failed' => 'danger',
                                        'processing' => 'warning',
                                        default => 'secondary',
                                    };
                                ?>

                                <span class="badge bg-<?php echo e($badgeClass); ?>">
                                    <?php echo e(ucfirst($batch->status)); ?>

                                </span>
                            </td>

                            <td>
                                <?php echo e($batch->created_at?->format('Y-m-d H:i')); ?>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="9" class="text-center py-4">
                                No import history found.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>

            </table>

        </div>

        <div class="card-footer">
            <?php echo e($batches->links()); ?>

        </div>

    </div>

</div>

</body>
</html>
<?php /**PATH C:\Users\pc\Music\Crises-dashboard\resources\views/imports/history/index.blade.php ENDPATH**/ ?>